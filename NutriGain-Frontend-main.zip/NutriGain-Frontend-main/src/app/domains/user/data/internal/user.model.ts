// src/app/domains/user/data/internal/user.model.ts
export interface User {
  id: number;
  nombre: string;
  email: string;
  password: string;
  edad: number;
  caminoSeleccionado: number;
}
